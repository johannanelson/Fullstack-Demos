const db = require('./db');
const User = require('./models/user-model');

module.exports = {
  db,
  User,
};
